# Diagramas de arquitectura (Segundo Parcial)

Fuente editable de cada diagrama y su PNG. Reflejan `main` @ 8b38f1a.

| Diagrama | Fuente | Imagen |
|---|---|---|
| Componentes | `01-componentes.mmd` (Mermaid) | `01-componentes.png` |
| Despliegue (Docker Compose) | `02-despliegue.dot` (Graphviz) | `02-despliegue.png` |
| Comunicación | `03-comunicacion.dot` (Graphviz) | `03-comunicacion.png` |
| Secuencia: sesión y Redis | `04-secuencia-sesion.mmd` | `04-secuencia-sesion.png` |
| Secuencia: cadena de negocio | `05-secuencia-cadena.mmd` | `05-secuencia-cadena.png` |

Regenerar:

```bash
npx -p @mermaid-js/mermaid-cli@11.4.2 mmdc -c mermaid-config.json -i 01-componentes.mmd -o 01-componentes.png -b white -s 2 -w 2000
npx -p @mermaid-js/mermaid-cli@11.4.2 mmdc -c mermaid-config.json -i 04-secuencia-sesion.mmd -o 04-secuencia-sesion.png -b white -s 2 -w 1600
npx -p @mermaid-js/mermaid-cli@11.4.2 mmdc -c mermaid-config.json -i 05-secuencia-cadena.mmd -o 05-secuencia-cadena.png -b white -s 2 -w 1600
dot -Tpng -Gdpi=170 02-despliegue.dot -o 02-despliegue.png
dot -Tpng -Gdpi=170 03-comunicacion.dot -o 03-comunicacion.png
```
